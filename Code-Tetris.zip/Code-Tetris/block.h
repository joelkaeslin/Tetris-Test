#pragma once
#include <vector>
#include <map>
#include "position.h"
#include "color.h"

class Block
{
public:
    Block();
    void Draw(int offsetX, int offsetY, Texture2D sheet);
    void Move(int rows, int colums);
    std::vector<Position> GetCellPosition();
    void Rotate();
    void UndoRotation();
    int id;
    std::map<int, std::vector<Position>> cells;

private:
    int rotationState;
    std::vector<Color> colors;
    int rowOffset;
    int columnOffset;
};