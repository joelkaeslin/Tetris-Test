#pragma once
#include <vector>
#include <raylib.h>
#include "constants.h"

class Grid
{
public:
    Grid();
    void Initialize();
    void Print();
    void Draw(Texture2D sheet);
    bool IsCellOutside(int row, int column);
    bool IsCellEmpty(int row, int column);
    int ClearFullRows();
    int grid[GRID_ROWS][GRID_COLS];

private:
    bool IsRowFull(int row);
    void ClearRow(int row);
    void MoveRowDown(int row, int numRows);
    std::vector<Color> colors;
};