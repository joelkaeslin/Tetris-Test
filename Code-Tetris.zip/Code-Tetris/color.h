#pragma once
#include <raylib.h>
#include <vector>

extern const Color darkGray;
extern const Color green;
extern const Color red;
extern const Color orange;
extern const Color yellow;
extern const Color purple;
extern const Color cyan;
extern const Color darkCyan;
extern const Color blue;
extern const Color lightBlue;
extern const Color Gray;
extern const Color lightGray;

std::vector<Color> GetCellColors();