#include "block.h"
#include "constants.h"

void DrawTetrisBlock(Texture2D sheet, int blockTyp, float targetX, float targetY, float displaySize);

Block::Block()
{
    rotationState = 0;
    colors = GetCellColors();
    rowOffset = 0;
    columnOffset = 0;
}
void Block::Draw(int offsetX, int offsetY, Texture2D sheet)
{
    std::vector<Position> tiles = GetCellPosition();
    for (Position item : tiles)
    {
        float screenX = (float)(item.column * CELL_SIZE + offsetX);
        float screenY = (float)(item.row * CELL_SIZE + offsetY);
        DrawTetrisBlock(sheet, id - 1, screenX, screenY, (float)CELL_SIZE);
    }
}

void Block::Move(int rows, int colums)
{
    rowOffset += rows;
    columnOffset += colums;
}
std::vector<Position> Block::GetCellPosition()
{
    std::vector<Position> tiles = cells[rotationState];
    std::vector<Position> movedTiles;
    for (Position item : tiles)
    {
        Position newPos = Position(item.row + rowOffset, item.column + columnOffset);
        movedTiles.push_back(newPos);
    }
    return movedTiles;
}

void Block::Rotate()
{
    rotationState++;
    if (rotationState == (int)cells.size())
    {
        rotationState = 0;
    }
}

void Block::UndoRotation()
{
    rotationState--;
    if (rotationState == -1)
    {
        rotationState = cells.size() - 1;
    }
}
