#pragma once
#include "grid.h"
#include "blocks.h"

enum GameState
{
    START_SCREEN,
    GAMEPLAY,
    GAME_OVER,
    SETTINGS,
    PAUSED
};

class Game
{
public:
    Game();
    ~Game();
    void Draw();
    void HandleInput();
    bool MoveBlockDown();
    void Reset();
    void UpdateLevel();
    int level = 1;
    int deletedRows = 0;
    bool showGhost = false;
    bool showResetConfirm = false;
    Rectangle GetGhostCheckbox();
    Rectangle GetSoundCheckbox();
    Rectangle GetSettingsCheckbox();
    Rectangle GetResetButton();
    Rectangle GetConfirmYesButton();
    Rectangle GetConfirmNoButton();
    float GetSettingsTextX();
    
    bool gameOver;
    int score;
    int highScore;
    int loadHighScore();
    void checkAndSaveHighScore();
    void LoadSettings();
    void SaveSettings();
    void SaveHighScore();
    void ResetHighScore();

    Font font;
    Image settingsImage;
    Image soundImage;
    Texture2D settingsTexture;
    Texture2D soundOffTexture;
    Texture2D soundOnTexture;
    Texture2D arrowTexture;
    Music music;
    Sound gameOverSound;

    GameState currentGameState = START_SCREEN;
    float musicVolume = 0.5f;
    void UpdateSoundVolumes();

private:
    void MoveBlockLeft();
    void MoveBlockRight();
    void HardDrop();
    int GetDropDistance();
    void DrawGhost();
    Block GetRandomBlock();
    std::vector<Block> GetAllBlocks();
    bool IsBlockOutside();
    void RotateBlock();
    void LockBlock();
    bool BlockFits();
    void UpdateScore(int linesCleared);

    Texture2D blockSheet;
    Grid grid;
    std::vector<Block> blocks;
    Block currentBlock;
    Block nextBlock;
    Sound rotateSound;
    Sound clearSound;
};