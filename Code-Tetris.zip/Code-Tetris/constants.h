#pragma once

constexpr int SCREEN_WIDTH = 1400;
constexpr int SCREEN_HEIGHT = 1240;
constexpr int CELL_SIZE = 60;
constexpr int GRID_OFFSET = 22;
constexpr int GRID_ROWS = 20;
constexpr int GRID_COLS = 10;
constexpr int ROWS_PER_LEVEL = 5;
constexpr int NEXT_BOX_X = 650;
constexpr int NEXT_BOX_Y = 560;
constexpr int NEXT_BOX_WIDTH = 340;
constexpr int NEXT_BOX_HEIGHT = 360;
constexpr int HELP_BOX_X = 1025;
constexpr int HELP_BOX_Y = 560;
constexpr int HELP_BOX_WIDTH = 340;
constexpr int HELP_BOX_HEIGHT = 450;