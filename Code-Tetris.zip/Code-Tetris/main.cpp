#include <raylib.h>
#include "game.h"
#include "color.h"
#include "constants.h"
#include <iostream>
#include <fstream>

double lastUpdateTime = 0;

bool EventTriggered(double interval)
{
    double currentTime = GetTime();
    if (currentTime - lastUpdateTime >= interval)
    {
        lastUpdateTime = currentTime;
        return true;
    }
    return false;
}

void DrawTextCentered(Font font, const char *text, int fontSize, float spacing, float y, Color color)
{
    Vector2 TextSize = MeasureTextEx(font, text, fontSize, spacing);
    float textX = (SCREEN_WIDTH - TextSize.x) / 2.0f;
    DrawTextEx(font, text, (Vector2){textX, y}, fontSize, spacing, color);
}

void DrawSettingsButton(Game &game)
{
    DrawCircle(1320, 80, 70, lightGray);
    Rectangle sourceRec = {0.0f, 0.0f, (float)game.settingsTexture.width, (float)game.settingsTexture.height};
    Rectangle destRec = {1250.0f, 10.0f, 140.0f, 140.0f};
    Vector2 origin = {0.0f, 0.0f};
    DrawTexturePro(game.settingsTexture, sourceRec, destRec, origin, 0.0f, WHITE);
    DrawCircle(1285, 115, 25, Gray);
    DrawTextEx(game.font, "E", {1275, 88}, 50, 4, WHITE);
}

void DrawGameInfo(Game &game)
{
    DrawTextEx(game.font, "Create by Joel Kaeslin", {10, 1208}, 24, 4, WHITE);
    DrawTextEx(game.font, "V.1.0.0", {1290, 1208}, 24, 4, WHITE);
}

void DrawScorePanel(const Game &game)
{
    DrawRectangleRounded({650, 100, 340, 120}, 0.6, 12, lightGray);
    DrawRectangleRounded({1025, 100, 340, 120}, 0.6, 12, lightGray);
    DrawRectangleRounded({1025, 330, 340, 120}, 0.6, 12, lightGray);
    DrawRectangleRounded({HELP_BOX_X, HELP_BOX_Y, HELP_BOX_WIDTH, HELP_BOX_HEIGHT}, 0.3, 12, lightGray);

    DrawTextEx(game.font, "Score", {730, 20}, 76, 4, WHITE);
    DrawTextEx(game.font, "High Score", {1000, 20}, 76, 4, WHITE);
    DrawTextEx(game.font, "Level", {1105, 250}, 76, 4, WHITE);
    DrawTextEx(game.font, "Next", {NEXT_BOX_X + 100, NEXT_BOX_Y - 80}, 76, 4, WHITE);
    DrawTextEx(game.font, "Hilfe", {HELP_BOX_X + 80, HELP_BOX_Y - 80}, 76, 4, WHITE);
    DrawTextEx(game.font, "Left", {HELP_BOX_X + 25, HELP_BOX_Y + 10}, 56, 4, WHITE);
    Rectangle leftSourceRec = { 0.0f, 0.0f, (float)game.arrowTexture.width, (float)game.arrowTexture.height };
    Rectangle leftDestRec = { HELP_BOX_X + 300, HELP_BOX_Y + 45, 70.0f, 70.0f }; 
    Vector2 leftOrigin = { leftDestRec.width / 2.0f, leftDestRec.height / 2.0f };
    float leftRotationAngle = 270.0f;
    DrawTexturePro(game.arrowTexture, leftSourceRec, leftDestRec, leftOrigin, leftRotationAngle, WHITE);
    DrawTextEx(game.font, "Right", {HELP_BOX_X + 25,HELP_BOX_Y + 70}, 56, 4, WHITE);
    Rectangle rightSourceRec = { 0.0f, 0.0f, (float)game.arrowTexture.width, (float)game.arrowTexture.height };
    Rectangle rightDestRec = { HELP_BOX_X + 300, HELP_BOX_Y + 105, 70.0f, 70.0f }; 
    Vector2 rightOrigin = { rightDestRec.width / 2.0f, rightDestRec.height / 2.0f };
    float rightRotationAngle = 0.0f;
    DrawTexturePro(game.arrowTexture, rightSourceRec, rightDestRec, rightOrigin, rightRotationAngle, WHITE);
    DrawTextEx(game.font, "Down", {HELP_BOX_X + 25, HELP_BOX_Y + 130}, 56, 4, WHITE);
    Rectangle downSourceRec = { 0.0f, 0.0f, (float)game.arrowTexture.width, (float)game.arrowTexture.height };
    Rectangle downDestRec = { HELP_BOX_X + 300, HELP_BOX_Y + 165, 70.0f, 70.0f }; 
    Vector2 downOrigin = { downDestRec.width / 2.0f, downDestRec.height / 2.0f };
    float downRotationAngle = 90.0f;
    DrawTexturePro(game.arrowTexture, downSourceRec, downDestRec, downOrigin, downRotationAngle, WHITE);
    DrawTextEx(game.font, "Rotate", {HELP_BOX_X + 25, HELP_BOX_Y + 190}, 56, 4, WHITE);
    Rectangle rotateSourceRec = { 0.0f, 0.0f, (float)game.arrowTexture.width, (float)game.arrowTexture.height };
    Rectangle rotateDestRec = { HELP_BOX_X + 300, HELP_BOX_Y + 225, 70.0f, 70.0f }; 
    Vector2 rotateOrigin = { rotateDestRec.width / 2.0f, rotateDestRec.height / 2.0f };
    float rotateRotationAngle = 180.0f;
    DrawTexturePro(game.arrowTexture, rotateSourceRec, rotateDestRec, rotateOrigin, rotateRotationAngle, WHITE);
    DrawTextEx(game.font, "Drop", {HELP_BOX_X + 25, HELP_BOX_Y + 250}, 56, 4, WHITE);
    DrawTextEx(game.font, "SPACE", {HELP_BOX_X + 180, HELP_BOX_Y + 250}, 56, 4, WHITE);
    DrawTextEx(game.font, "Pause", {HELP_BOX_X + 25, HELP_BOX_Y + 310}, 56, 4, WHITE);
    DrawTextEx(game.font, "P", {HELP_BOX_X + 295, HELP_BOX_Y + 310}, 56, 4, WHITE);
    DrawTextEx(game.font, "Quit", {HELP_BOX_X + 25, HELP_BOX_Y + 370}, 56, 4, WHITE);
    DrawTextEx(game.font, "Esc", {HELP_BOX_X + 240, HELP_BOX_Y + 370}, 56, 4, WHITE);
    

    char scoreText[10];
    sprintf(scoreText, "%d", game.score);
    Vector2 textSize = MeasureTextEx(game.font, scoreText, 76, 4);
    DrawTextEx(game.font, scoreText, {650 + (340 - textSize.x) / 2, 120}, 76, 4, WHITE);

    char highScoreText[10];
    sprintf(highScoreText, "%d", game.highScore);
    textSize = MeasureTextEx(game.font, highScoreText, 76, 4);
    DrawTextEx(game.font, highScoreText, {1025 + (340 - textSize.x) / 2, 120}, 76, 4, WHITE);

    char levelText[10];
    sprintf(levelText, "%d", game.level);
    textSize = MeasureTextEx(game.font, levelText, 76, 4);
    DrawTextEx(game.font, levelText, {1025 + (340 - textSize.x) / 2, 350}, 76, 4, WHITE);

    DrawRectangleRounded({NEXT_BOX_X, NEXT_BOX_Y, NEXT_BOX_WIDTH, NEXT_BOX_HEIGHT}, 0.3, 12, lightGray);
}

void DrawButton(Font font, Rectangle rect, const char *label)
{
    DrawRectangleRounded(rect, 0.3f, 12, RED);

    int fontSize = 40;
    float spacing = 4.0f;
    Vector2 textSize = MeasureTextEx(font, label, fontSize, spacing);

    float textX = rect.x + (rect.width - textSize.x) / 2.0f;
    float textY = rect.y + (rect.height - textSize.y) / 2.0f;

    DrawTextEx(font, label, {textX, textY}, fontSize, spacing, WHITE);
}

int main()
{
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Tetris");
    SetTargetFPS(60);
    SetExitKey(KEY_X);
    GameState currentScreen = START_SCREEN;
    Game game = Game();
    
    while (!WindowShouldClose())
    {
        SetMouseCursor(MOUSE_CURSOR_DEFAULT);
        if (IsKeyPressed(KEY_ESCAPE))
        {
            if (currentScreen == SETTINGS)
            {
                if (game.showResetConfirm)
                    game.showResetConfirm = false;
                else
                    currentScreen = START_SCREEN;
            }
            else if (currentScreen == GAMEPLAY || currentScreen == PAUSED || currentScreen == GAME_OVER)
            {
                currentScreen = START_SCREEN;
                game.Reset();
                StopMusicStream(game.music);
            }
            else if (currentScreen == START_SCREEN)
            {
                break;
            }
        }
        UpdateMusicStream(game.music);
        game.currentGameState = currentScreen;
        game.HandleInput();

        switch (currentScreen)
        {
        case START_SCREEN:
        {
            if (IsKeyPressed(KEY_SPACE))
            {
                currentScreen = GAMEPLAY;
                PlayMusicStream(game.music);
            }
            else if (IsKeyPressed(KEY_E))
            {
                currentScreen = SETTINGS;
            }
            Vector2 mousePos = GetMousePosition();
            Rectangle settingsBox = game.GetSettingsCheckbox();
            if (CheckCollisionPointRec(mousePos, settingsBox))
                {
                    SetMouseCursor(MOUSE_CURSOR_POINTING_HAND);
                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
                    {
                        currentScreen = SETTINGS;
                    }
                }
            break;
        }
        case SETTINGS:
        {
            if (IsKeyPressed(KEY_E))
            {
                if (game.showResetConfirm)
                    game.showResetConfirm = false;
                else
                    currentScreen = START_SCREEN;
            }
            Vector2 mousePos = GetMousePosition();
            Rectangle settingsBox = game.GetSettingsCheckbox();
            if (!game.showResetConfirm && CheckCollisionPointRec(mousePos, settingsBox))
            {
                SetMouseCursor(MOUSE_CURSOR_POINTING_HAND);

                if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
                {
                    currentScreen = START_SCREEN;
                }
            }
            break;
        }
        case GAMEPLAY:
            if (IsKeyPressed(KEY_P))
            {
                PauseMusicStream(game.music);
                currentScreen = PAUSED;
            }

            else if (game.gameOver)
            {
                currentScreen = GAME_OVER;
            }
            else
            {
                double speedInterval = 0.4 - (game.level - 1) * 0.02;

                if (speedInterval < 0.1)
                {
                    speedInterval = 0.1;
                }
                if (EventTriggered(speedInterval))
                {
                    game.MoveBlockDown();
                }
            }
            break;

        case PAUSED:
            if (IsKeyPressed(KEY_P))
            {
                ResumeMusicStream(game.music);
                currentScreen = GAMEPLAY;
            }
            break;

        case GAME_OVER:
            if (IsKeyPressed(KEY_SPACE))
            {
                game.Reset();
                currentScreen = GAMEPLAY;
                PlayMusicStream(game.music);
            }
            
            break;
        }

        BeginDrawing();
        switch (currentScreen)
        {
        case START_SCREEN:
        {
            ClearBackground(Gray);
            const char *titleText = "TETRIS";
            Color colors[] = {green, orange, red, purple, blue, cyan};
            int titleFontSize = 300;
            float titleSpacing = 4.0f;

            Vector2 titleSize = MeasureTextEx(game.font, titleText, titleFontSize, titleSpacing);
            float startX = (SCREEN_WIDTH - titleSize.x) / 2.0f;
            float titleY = 400.0f;

            DrawRectangleRounded({startX - 50, 435, 940, 325}, 0, 12, darkCyan);
            DrawRectangleRounded({startX - 45, 440, 930, 315}, 0, 12, Gray);

            float currentX = startX;
            for (int i = 0; i < 6; i++)
            {
                char singleChar[2] = {titleText[i], '\0'};
                DrawTextEx(game.font, singleChar, (Vector2){currentX, titleY}, titleFontSize, titleSpacing, colors[i]);

                Vector2 charSize = MeasureTextEx(game.font, singleChar, titleFontSize, titleSpacing);
                currentX += charSize.x + titleSpacing;
            }

            DrawTextCentered(game.font, "PRESS SPACE TO START", 72, 4.0f, 650.0f, darkCyan);

            DrawSettingsButton(game);

            DrawGameInfo(game);

            break;
        }

        case GAMEPLAY:
        {
            ClearBackground(Gray);

            DrawScorePanel(game);

            game.Draw();
            break;
        }

        case GAME_OVER:
        {
            ClearBackground(Gray);

            DrawScorePanel(game);

            game.Draw();

            DrawRectangleRounded({450, 370, 500, 500}, 0.05, 12, RED);
            DrawRectangleRounded({460, 380, 480, 480}, 0.05, 12, Gray);
            DrawTextCentered(game.font, "GAME OVER", 76, 4.0f, 465.0f, RED);
            DrawTextCentered(game.font, "PRESS SPACE", 70, 4.0f, 565.0f, WHITE);
            DrawTextCentered(game.font, "FOR NEW GAME", 70, 4.0f, 665.0f, WHITE);

            break;
        }

        case PAUSED:
        {
            ClearBackground(Gray);

            DrawRectangleRounded({500, 420, 400, 400}, 0.1, 12, WHITE);
            DrawRectangleRounded({510, 430, 380, 380}, 0.05, 12, Gray);
            DrawTextCentered(game.font, "PAUSED", 76, 4.0f, 485.0f, WHITE);
            DrawTextCentered(game.font, "PRESS P", 70, 4.0f, 585.0f, WHITE);
            DrawTextCentered(game.font, "TO RESUME", 70, 4.0f, 685.0f, WHITE);

            break;
        }

        case SETTINGS:
        {
            ClearBackground(Gray);

            const char *settingsText = "SETTINGS";
            int settingsFontSize = 172;
            float settingsSpacing = 4.0f;

            float settingsTextX = game.GetSettingsTextX();
            float settingsTextY = 150.0f;

            DrawTextEx(game.font, settingsText, (Vector2){settingsTextX, settingsTextY}, settingsFontSize, settingsSpacing, WHITE);

            DrawText(TextFormat("Music Volume %i%%", (int)(game.musicVolume * 100 + 0.5f)), settingsTextX, 380, 40, WHITE);

            float sX = settingsTextX + 70;
            float sY = 470.0f;
            float sWidth = 400.0f;
            float sHeight = 20.0f;

            DrawRectangleRounded({sX, sY, sWidth, sHeight}, 1.0f, 4, GRAY);

            DrawRectangleRounded({sX, sY, sWidth * game.musicVolume, sHeight}, 1.0f, 4, darkCyan);

            float buttonX = sX + (sWidth * game.musicVolume);
            float buttonY = sY + (sHeight / 2.0f);
            DrawCircle(buttonX, buttonY, 15, WHITE);

            if (game.musicVolume > 0.01f)
            {
                Rectangle sourceRec = {0.0f, 0.0f, (float)game.soundOnTexture.width, (float)game.soundOnTexture.height};
                Rectangle destRec = {settingsTextX, 460.0f, 40.0f, 40.0f};
                Vector2 origin = {0.0f, 0.0f};
                DrawTexturePro(game.soundOnTexture, sourceRec, destRec, origin, 0.0f, WHITE);
            }
            else if (game.musicVolume <= 0.01f)
            {
                Rectangle sourceRec = {0.0f, 0.0f, (float)game.soundOffTexture.width, (float)game.soundOffTexture.height};
                Rectangle destRec = {settingsTextX, 460.0f, 40.0f, 40.0f};
                Vector2 origin = {0.0f, 0.0f};
                DrawTexturePro(game.soundOffTexture, sourceRec, destRec, origin, 0.0f, WHITE);
            }
            
            DrawCircle(settingsTextX + 20, 680, 20, BLACK);
            DrawCircle(settingsTextX + 20, 680, 15, WHITE);
            if (game.showGhost)
            {
                DrawCircle(settingsTextX + 20, 680, 10, BLACK);
            }

            DrawTextEx(game.font, "Use arrow keys / M to mute", {settingsTextX, 540}, 40, 4, GRAY);
            DrawTextEx(game.font, TextFormat("Ghost Block %s", game.showGhost ? "ON" : "OFF"), {settingsTextX + 70, 660}, 40, 4, WHITE);
            DrawTextEx(game.font, "G: Ghost Block on/off", {settingsTextX, 720}, 40, 4, GRAY);

            DrawButton(game.font, game.GetResetButton(), "Reset Highscore");

            DrawTextEx(game.font, "Press E to exit", {settingsTextX, 1000}, 60, 4, WHITE);

            DrawSettingsButton(game);

            DrawGameInfo(game);

            if (game.showResetConfirm)
            {
                DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Fade(BLACK, 0.7f));
                DrawRectangleRounded({300, 400, 800, 400}, 0.05, 12, RED);
                DrawRectangleRounded({310, 410, 780, 380}, 0.05, 12, Gray);
                DrawTextCentered(game.font, "DELETE HIGHSCORE?", 76, 4.0f, 440.0f, WHITE);
                DrawTextCentered(game.font, "THIS CANNOT BE UNDONE", 50, 4.0f, 530.0f, WHITE);
                DrawButton(game.font, game.GetConfirmYesButton(), "Yes, delete");
                DrawButton(game.font, game.GetConfirmNoButton(), "Cancel");
            }

            break;
        }
        }

        EndDrawing();
    }
    game.SaveSettings();
    CloseWindow();
    return 0;
}