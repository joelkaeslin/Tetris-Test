#include "game.h"
#include "constants.h"
#include <random>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <cstdlib>

unsigned int ComputeChecksum(int value)
{
    unsigned int hash = 2166136261u;
    std::string text = std::to_string(value) + "MeinErsterGeheimerTextIstSoGeheimDassNiemandEsErratenKann";
    for (char c : text)
    {
        hash ^= (unsigned char)c;
        hash *= 16777619u;
    }
    return hash;
}

std::string Scramble(const std::string &text)
{
    const std::string key = "MeinZweiterLangerGeheimerSchluesselIstVielLängerAlsDerErsteUndNiemandKannEsErratenWeilErSoGeheimIstWieDieErsteGeheimeNachrichtUndEinfachLängerAlsDieErsteGeheimeNachrichtUndNiemandKannEsErratenWeilEsSoGeheimIst";
    std::string result = text;
    for (size_t i = 0; i < result.size(); i++)
    {
        result[i] = (char)(result[i] ^ key[i % key.size()]);
    }
    return result;
}

std::string ToHex(const std::string &data)
{
    const char *digits = "0123456789ABCDEF";
    std::string hex;
    for (unsigned char c : data)
    {
        hex += digits[c / 16];
        hex += digits[c % 16];
    }
    return hex;
}

std::string FromHex(const std::string &hex)
{
    std::string data;
    for (size_t i = 0; i + 1 < hex.size(); i += 2)
    {
        data += (char)std::strtol(hex.substr(i, 2).c_str(), nullptr, 16);
    }
    return data;
}

Game::Game()
{
    grid = Grid();
    blocks = GetAllBlocks();
    currentBlock = GetRandomBlock();
    nextBlock = GetRandomBlock();
    gameOver = false;
    score = 0;
    highScore = loadHighScore();
    blockSheet = LoadTexture("Image/tetris-Sheet-outline.png");
    Image settingsImage = LoadImage("Image/Settings-Image.png");
    settingsTexture = LoadTextureFromImage(settingsImage);
    UnloadImage(settingsImage);
    Image soundOffImage = LoadImage("Image/soundOffWhite.png");
    soundOffTexture = LoadTextureFromImage(soundOffImage);
    UnloadImage(soundOffImage);
    Image soundOnImage = LoadImage("Image/soundOnWhite.png");
    soundOnTexture = LoadTextureFromImage(soundOnImage);
    UnloadImage(soundOnImage);
    Image arrowImage = LoadImage("Image/Arrow-removebg-preview (1).png");
    arrowTexture = LoadTextureFromImage(arrowImage);
    UnloadImage(arrowImage);
    InitAudioDevice();
    music = LoadMusicStream("Sounds/Tetris Music.mp3");
    rotateSound = LoadSound("Sounds/rotate.mp3");
    clearSound = LoadSound("Sounds/clear.mp3");
    gameOverSound = LoadSound("Sounds/06. Game Over.mp3");
    font = LoadFontEx("Font/monogram.ttf", 128, 0, 0);
    LoadSettings();
    UpdateSoundVolumes();
}

Game::~Game()
{
    UnloadTexture(blockSheet);
    UnloadTexture(settingsTexture);
    UnloadTexture(soundOffTexture);
    UnloadTexture(soundOnTexture);
    UnloadTexture(arrowTexture);
    UnloadSound(rotateSound);
    UnloadSound(clearSound);
    UnloadSound(gameOverSound);
    UnloadMusicStream(music);
    CloseAudioDevice();
    UnloadFont(font);
}

void DrawTetrisBlock(Texture2D sheet, int blockTyp, float targetX, float targetY, float displaySize)
{

    float nativeSize = (float)sheet.width / 11.0f;

    Rectangle sourceRect = {
        (float)blockTyp * nativeSize,
        0.0f,
        nativeSize,
        nativeSize};

    Rectangle destRect = {
        targetX,
        targetY,
        displaySize,
        displaySize};

    Vector2 origin = {0.0f, 0.0f};

    DrawTexturePro(sheet, sourceRect, destRect, origin, 0.0f, WHITE);
}

Block Game::GetRandomBlock()
{
    if (blocks.empty())
    {
        blocks = GetAllBlocks();
    }
    int randomIndex = rand() % blocks.size();
    Block block = blocks[randomIndex];
    blocks.erase(blocks.begin() + randomIndex);
    return block;
}

std::vector<Block> Game::GetAllBlocks()
{
    return {IBlock(), JBlock(), LBlock(), OBlock(), SBlock(), TBlock(), ZBlock()};
}

int Game::GetDropDistance()
{
    int distance = 0;
    while (true)
    {
        currentBlock.Move(1, 0);
        if (IsBlockOutside() || BlockFits() == false)
        {
            currentBlock.Move(-1, 0);
            break;
        }
        distance++;
    }
    currentBlock.Move(-distance, 0);
    return distance;
}

void Game::DrawGhost()
{
    int distance = GetDropDistance();
    Block ghost = currentBlock;
    ghost.Move(distance, 0);
    std::vector<Position> tiles = ghost.GetCellPosition();
    for (Position item : tiles)
    {
        float screenX = (float)(item.column * CELL_SIZE + GRID_OFFSET);
        float screenY = (float)(item.row * CELL_SIZE + GRID_OFFSET);
        DrawRectangleLinesEx({screenX, screenY, (float)CELL_SIZE, (float)CELL_SIZE}, 1, Fade(WHITE, 0.5f));
    }
}

void Game::Draw()
{
    grid.Draw(blockSheet);
    if (!gameOver && showGhost == true)
    {
        DrawGhost();
    }
    currentBlock.Draw(GRID_OFFSET, GRID_OFFSET, blockSheet);

    switch (nextBlock.id)
    {
    case 3:
        nextBlock.Draw(NEXT_BOX_X - 130, NEXT_BOX_Y + 150, blockSheet);
        break;
    case 4:
        nextBlock.Draw(NEXT_BOX_X - 130, NEXT_BOX_Y + 120, blockSheet);
        break;
    default:
        nextBlock.Draw(NEXT_BOX_X - 100, NEXT_BOX_Y + 110, blockSheet);
        break;
    }
}

float Game::GetSettingsTextX()
{
    const char *settingsText = "Einstellungen";
    int settingsFontSize = 172;
    float settingsSpacing = 4.0f;
    Vector2 settingsTextSize = MeasureTextEx(font, settingsText, settingsFontSize, settingsSpacing);
    return (SCREEN_WIDTH - settingsTextSize.x) / 2.0f;
}

Rectangle Game::GetGhostCheckbox()
{
    float settingsTextX = GetSettingsTextX();
    return {settingsTextX, 660.0f, 40.0f, 40.0f};
}

Rectangle Game::GetSoundCheckbox()
{
    float settingsTextX = GetSettingsTextX();

    return {settingsTextX, 460.0f, 40.0f, 40.0f};
}

Rectangle Game::GetSettingsCheckbox()
{
    return {1250, 10.0f, 140.0f, 140.0f};
}

Rectangle Game::GetResetButton()
{
    return { GetSettingsTextX(), 900.0f, 400.0f, 60.0f };
}

Rectangle Game::GetConfirmYesButton()
{
    return {360.0f, 650.0f, 320.0f, 80.0f};
}

Rectangle Game::GetConfirmNoButton()
{
    return {720.0f, 650.0f, 320.0f, 80.0f};
}

void Game::UpdateSoundVolumes()
{
    SetMusicVolume(music, musicVolume);
    SetSoundVolume(rotateSound, musicVolume);
    SetSoundVolume(clearSound, musicVolume);
    SetSoundVolume(gameOverSound, musicVolume);
}

void Game::HandleInput()
{
    if (currentGameState == SETTINGS)
    {

        float settingsTextX = GetSettingsTextX();
        float sliderX = settingsTextX + 70;
        float sliderY = 470.0f;
        float sliderWidth = 400.0f;
        float sliderHeight = 20.0f;

        Vector2 mousePos = GetMousePosition();

        if (showResetConfirm)
        {
            Rectangle noBox = GetConfirmNoButton();
            if (CheckCollisionPointRec(mousePos, noBox))
            {
                SetMouseCursor(MOUSE_CURSOR_POINTING_HAND);
                if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
                {
                    showResetConfirm = false;
                }
            }

            Rectangle yesBox = GetConfirmYesButton();
            if (CheckCollisionPointRec(mousePos, yesBox))
            {
                SetMouseCursor(MOUSE_CURSOR_POINTING_HAND);
                if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
                {
                    ResetHighScore();
                    showResetConfirm = false;
                }
            }
            return;
        }

        Rectangle resetBox = GetResetButton();
        if (CheckCollisionPointRec(mousePos, resetBox))
        {
            SetMouseCursor(MOUSE_CURSOR_POINTING_HAND);
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            {
            showResetConfirm = true;
            }
        }

        if (mousePos.x >= sliderX && mousePos.x <= (sliderX + sliderWidth) &&
            mousePos.y >= (sliderY - 20) && mousePos.y <= (sliderY + sliderHeight + 20))
        {

            SetMouseCursor(MOUSE_CURSOR_POINTING_HAND);

            if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
            {
                musicVolume = (mousePos.x - sliderX) / sliderWidth;
            }
        }

        Rectangle ghostBox = GetGhostCheckbox();
        if (CheckCollisionPointRec(mousePos, ghostBox))
        {
            SetMouseCursor(MOUSE_CURSOR_POINTING_HAND);

            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            {
                showGhost = !showGhost;
            }
        }

        Rectangle soundBox = GetSoundCheckbox();
        if (CheckCollisionPointRec(mousePos, soundBox))
        {
            SetMouseCursor(MOUSE_CURSOR_POINTING_HAND);

            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            {
                if (musicVolume > 0.0f)
                    musicVolume = 0.0f;
                else
                    musicVolume = 0.5f;
            }
        }

        if (IsKeyPressed(KEY_RIGHT) && musicVolume < 1.0f)
        {
            musicVolume += 0.1f;
            if (musicVolume > 1.0f)
                musicVolume = 1.0f;
        }
        if (IsKeyPressed(KEY_LEFT) && musicVolume > 0.0f)
        {
            musicVolume -= 0.1f;
            if (musicVolume < 0.01f)
                musicVolume = 0.0f;
        }
        if (IsKeyPressed(KEY_M))
        {
            if (musicVolume > 0.0f)
                musicVolume = 0.0f;
            else
                musicVolume = 0.5f;
        }

        if(IsKeyPressed(KEY_G)){
            showGhost = !showGhost;
        }

        UpdateSoundVolumes();

        return;
    }

    if (currentGameState == GAMEPLAY)
    {
        if (gameOver && IsKeyPressed(KEY_SPACE))
        {
            gameOver = false;
            Reset();
            return;
        }
        if (IsKeyPressed(KEY_LEFT) || IsKeyPressedRepeat(KEY_LEFT))
        {
            MoveBlockLeft();
        }

        if (IsKeyPressed(KEY_RIGHT) || IsKeyPressedRepeat(KEY_RIGHT))
        {
            MoveBlockRight();
        }

        if (IsKeyPressed(KEY_DOWN) || IsKeyPressedRepeat(KEY_DOWN))
        {
            MoveBlockDown();
        }

        if (IsKeyPressed(KEY_UP))
        {
            RotateBlock();
        }

        if (IsKeyPressed(KEY_SPACE))
        {
            HardDrop();
        }
    }
}

void Game::MoveBlockLeft()
{
    if (!gameOver)
    {
        currentBlock.Move(0, -1);
        if (IsBlockOutside() || BlockFits() == false)
        {
            currentBlock.Move(0, 1);
        }
    }
}

void Game::MoveBlockRight()
{
    if (!gameOver)
    {
        currentBlock.Move(0, 1);
        if (IsBlockOutside() || BlockFits() == false)
        {
            currentBlock.Move(0, -1);
        }
    }
}

bool Game::MoveBlockDown()
{
    if (gameOver)
        return false;
    currentBlock.Move(1, 0);
    if (IsBlockOutside() || BlockFits() == false)
    {
        currentBlock.Move(-1, 0);
        LockBlock();
        return false;
    }
    return true;
}

void Game::HardDrop()
{
    if(gameOver) return;
    int distance = GetDropDistance();
    currentBlock.Move(distance, 0);
    score += distance;
    LockBlock();
}

bool Game::IsBlockOutside()
{
    std::vector<Position> tiles = currentBlock.GetCellPosition();
    for (Position item : tiles)
    {
        if (grid.IsCellOutside(item.row, item.column))
        {
            return true;
        }
    }
    return false;
}

void Game::RotateBlock()
{
    if (!gameOver)
    {
        currentBlock.Rotate();
        if (IsBlockOutside() || BlockFits() == false)
        {
            currentBlock.UndoRotation();
        }
        else
        {
            PlaySound(rotateSound);
        }
    }
}

void Game::LockBlock()
{
    std::vector<Position> tiles = currentBlock.GetCellPosition();
    for (Position item : tiles)
    {
        grid.grid[item.row][item.column] = currentBlock.id;
        score++;
    }
    currentBlock = nextBlock;
    if (BlockFits() == false)
    {
        gameOver = true;
        PlaySound(gameOverSound);
        StopMusicStream(music);
        checkAndSaveHighScore();
    }
    nextBlock = GetRandomBlock();
    int rowsCleard = grid.ClearFullRows();
    if (rowsCleard > 0)
    {
        deletedRows += rowsCleard;
        UpdateLevel();
        PlaySound(clearSound);
        UpdateScore(rowsCleard);
    }
}

void Game::UpdateLevel()
{
    level = deletedRows / ROWS_PER_LEVEL + 1;
}

bool Game::BlockFits()
{
    std::vector<Position> tiles = currentBlock.GetCellPosition();
    for (Position item : tiles)
    {
        if (grid.IsCellEmpty(item.row, item.column) == false)
        {
            return false;
        }
    }
    return true;
}

void Game::Reset()
{
    grid.Initialize();
    blocks = GetAllBlocks();
    currentBlock = GetRandomBlock();
    nextBlock = GetRandomBlock();
    gameOver = false;
    score = 0;
    deletedRows = 0;
    level = 1;
    currentGameState = GAMEPLAY;
    PlayMusicStream(music);
}

void Game::UpdateScore(int linesCleared)
{
    switch (linesCleared)
    {
    case 1:
        score += 100;
        break;
    case 2:
        score += 200;
        break;
    case 3:
        score += 500;
        break;
    case 4:
        score += 1000;
        break;
    }
}

int Game::loadHighScore()
{
    int loadedScore = 0;
    unsigned int storedChecksum = 0;
    std::ifstream file("File/highscore.txt");

    if (file.is_open())
    {
        std::string hex;
        file >> hex;
        file.close();

        std::istringstream in(Scramble(FromHex(hex)));
        in >> loadedScore >> storedChecksum;

        if (storedChecksum != ComputeChecksum(loadedScore))
        {
            loadedScore = 0;
        }
    }
    return loadedScore;
}

void Game::checkAndSaveHighScore()
{
    if (score > highScore)
    {
        highScore = score;

        SaveHighScore();
    }
}

void Game::SaveHighScore()
{
    std::ofstream file("File/highscore.txt");
    if (file.is_open())
    {
        std::string plain = std::to_string(highScore) + " " + std::to_string(ComputeChecksum(highScore));
        file << ToHex(Scramble(plain));
        file.close();
    }
}

void Game::ResetHighScore()
{
    highScore = 0;
    SaveHighScore();
}

void Game::SaveSettings()
{
    std::ofstream file("File/settings.txt");
    if (file.is_open())
    {
        std::string plain = std::to_string(musicVolume) + " " + std::to_string((int)showGhost);
        file << ToHex(Scramble(plain));
        file.close();
    }
}

void Game::LoadSettings()
{
    std::ifstream file("File/settings.txt");
    std::string hex;
    file >> hex;
    file.close();

    std::istringstream in(Scramble(FromHex(hex)));
    float volume = 0.5f;
    int ghost = 0;
    if (in >> volume >> ghost)
    {
        musicVolume = volume;
        showGhost = (ghost != 0);
    }

    if (musicVolume < 0.0f) musicVolume = 0.0f;
    if (musicVolume > 1.0f) musicVolume = 1.0f;
}