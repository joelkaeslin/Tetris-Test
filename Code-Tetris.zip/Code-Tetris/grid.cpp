#include "grid.h"
#include "iostream"
#include "color.h"
#include "constants.h"

void DrawTetrisBlock(Texture2D sheet, int blockTyp, float targetX, float targetY, float displaySize);

Grid::Grid()
{
    Initialize();
    colors = GetCellColors();
}

void Grid::Initialize()
{
    for (int row = 0; row < GRID_ROWS; row++)
    {
        for (int column = 0; column < GRID_COLS; column++)
        {
            grid[row][column] = 0;
        }
    }
}

void Grid::Print()
{
    for (int row = 0; row < GRID_ROWS; row++)
    {
        for (int column = 0; column < GRID_COLS; column++)
        {
            std::cout << grid[row][column] << " ";
        }
        std::cout << std::endl;
    }
}

void Grid::Draw(Texture2D sheet)
{
    for (int row = 0; row < GRID_ROWS; row++)
    {
        for (int column = 0; column < GRID_COLS; column++)
        {
            int cellValue = grid[row][column];

            // 1. Hintergrund-Grid zeichnen (Größe dynamisch über CELL_SIZE)
            DrawRectangle(column * CELL_SIZE + GRID_OFFSET, row * CELL_SIZE + GRID_OFFSET, CELL_SIZE - 1, CELL_SIZE - 1, darkGray);

            // 2. Wenn ein Block da ist, Textur drüberzeichnen
            if (cellValue > 0)
            {
                float targetX = (float)column * CELL_SIZE + GRID_OFFSET;
                float targetY = (float)row * CELL_SIZE + GRID_OFFSET;

                // 👈 HIER JETZT AUCH "- 1" RECHNEN!
                DrawTetrisBlock(sheet, cellValue - 1, targetX, targetY, (float)CELL_SIZE);
            }
        }
    }
}

bool Grid::IsCellOutside(int row, int column)
{
    if (row >= 0 && row < GRID_ROWS && column >= 0 && column < GRID_COLS)
    {
        return false;
    }
    return true;
}

bool Grid::IsCellEmpty(int row, int column)
{
    if (grid[row][column] == 0)
    {
        return true;
    }
    return false;
}

int Grid::ClearFullRows()
{
    int completed = 0;
    for (int row = GRID_ROWS - 1; row >= 0; row--)
    {
        if (IsRowFull(row))
        {
            ClearRow(row);
            completed++;
        }
        else if (completed > 0)
        {
            MoveRowDown(row, completed);
        }
    }
    return completed;
}

bool Grid::IsRowFull(int row)
{
    for (int column = 0; column < GRID_COLS; column++)
    {
        if (grid[row][column] == 0)
        {
            return false;
        }
    }
    return true;
}

void Grid::ClearRow(int row)
{
    for (int column = 0; column < GRID_COLS; column++)
    {
        grid[row][column] = 0;
    }
}

void Grid::MoveRowDown(int row, int rowsToMove)
{
    for (int column = 0; column < GRID_COLS; column++)
    {
        grid[row + rowsToMove][column] = grid[row][column];
        grid[row][column] = 0;
    }
}
